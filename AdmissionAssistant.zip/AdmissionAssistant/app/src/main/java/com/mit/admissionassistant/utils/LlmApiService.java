
package com.mit.admissionassistant.utils;

import android.util.Log;

import com.mit.admissionassistant.BuildConfig;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LlmApiService {

    private static final String TAG = "LlmApiService";

    private static final String API_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/";

    public interface ApiCallback {
        void onSuccess(String response);
        void onError(String error);
    }

    public static void sendMessage(
            String userQuery,
            ApiCallback callback
    ) {
        String apiKey = BuildConfig.GEMINI_API_KEY;
        String model = BuildConfig.GEMINI_MODEL;

        if (apiKey == null || apiKey.trim().isEmpty()) {
            callback.onError(
                    "Gemini API key is missing. Check local.properties."
            );
            return;
        }

        if (model == null || model.trim().isEmpty()) {
            model = "gemini-3.8-flash";
        }

        final String selectedModel = model.trim();
        final String selectedApiKey = apiKey.trim();

        new Thread(() -> {
            HttpURLConnection conn = null;

            try {
                URL url = new URL(
                        API_URL + selectedModel + ":generateContent"
                );

                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty(
                        "x-goog-api-key",
                        selectedApiKey
                );
                conn.setRequestProperty(
                        "Content-Type",
                        "application/json; charset=UTF-8"
                );
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(45000);
                conn.setDoOutput(true);

                JSONObject requestBody = new JSONObject();

                // Instructions for the Admission Assistant
                JSONObject systemInstruction = new JSONObject();
                JSONArray systemParts = new JSONArray();

                JSONObject systemText = new JSONObject();
                systemText.put(
                        "text",
                        "You are a helpful College Admission Assistant. " +
                                "Answer student queries about courses, eligibility, " +
                                "tuition fees, required documents, and admission steps " +
                                "professionally using simple, concise language. " +
                                "Never invent college-specific fees, deadlines, or " +
                                "eligibility rules. If information is unavailable, " +
                                "ask the student to check the official college website."
                );

                systemParts.put(systemText);
                systemInstruction.put("parts", systemParts);
                requestBody.put("systemInstruction", systemInstruction);

                // User message
                JSONObject userPart = new JSONObject();
                userPart.put("text", userQuery);

                JSONArray userParts = new JSONArray();
                userParts.put(userPart);

                JSONObject userContent = new JSONObject();
                userContent.put("role", "user");
                userContent.put("parts", userParts);

                JSONArray contents = new JSONArray();
                contents.put(userContent);
                requestBody.put("contents", contents);

                // Response settings
                JSONObject generationConfig = new JSONObject();
                generationConfig.put("temperature", 0.5);
                generationConfig.put("maxOutputTokens", 700);
                requestBody.put("generationConfig", generationConfig);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = requestBody.toString()
                            .getBytes(StandardCharsets.UTF_8);
                    os.write(input);
                }

                int responseCode = conn.getResponseCode();

                InputStream responseStream =
                        responseCode >= 200 && responseCode < 300
                                ? conn.getInputStream()
                                : conn.getErrorStream();

                StringBuilder response = new StringBuilder();

                if (responseStream != null) {
                    try (BufferedReader reader =
                                 new BufferedReader(
                                         new InputStreamReader(
                                                 responseStream,
                                                 StandardCharsets.UTF_8
                                         ))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                    }
                }

                String responseBody = response.toString();

                if (responseCode >= 200 && responseCode < 300) {
                    JSONObject responseJson =
                            new JSONObject(responseBody);

                    JSONArray candidates =
                            responseJson.optJSONArray("candidates");

                    if (candidates == null || candidates.length() == 0) {
                        callback.onError(
                                "Gemini returned no answer. Please try again."
                        );
                        return;
                    }

                    JSONObject candidate = candidates.getJSONObject(0);
                    JSONObject content = candidate.optJSONObject("content");

                    JSONArray parts = content != null
                            ? content.optJSONArray("parts")
                            : null;

                    StringBuilder answer = new StringBuilder();

                    if (parts != null) {
                        for (int i = 0; i < parts.length(); i++) {
                            JSONObject part = parts.optJSONObject(i);

                            if (part != null) {
                                String text = part.optString("text", "");

                                if (!text.isEmpty()) {
                                    if (answer.length() > 0) {
                                        answer.append("\n");
                                    }
                                    answer.append(text);
                                }
                            }
                        }
                    }

                    if (answer.length() > 0) {
                        callback.onSuccess(answer.toString().trim());
                    } else {
                        callback.onError(
                                "Gemini returned an empty text response."
                        );
                    }

                } else {
                    Log.e(
                            TAG,
                            "Gemini API error: HTTP "
                                    + responseCode + " - " + responseBody
                    );

                    String message = "Gemini API error (HTTP "
                            + responseCode + "). ";

                    if (responseCode == 400) {
                        message += "Check the request format and model name.";
                    } else if (responseCode == 401
                            || responseCode == 403) {
                        message +=
                                "Check your API key, project permissions, "
                                        + "and API access.";
                    } else if (responseCode == 429) {
                        message +=
                                "The API quota or request limit may have "
                                        + "been reached.";
                    } else {
                        message += "Check Logcat for more details.";
                    }

                    callback.onError(message);
                }

            } catch (Exception e) {
                Log.e(TAG, "Exception calling Gemini API", e);

                callback.onError(
                        e.getMessage() != null
                                ? e.getMessage()
                                : "Network error while contacting Gemini."
                );

            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }
}
