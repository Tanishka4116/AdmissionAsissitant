package com.mit.admissionassistant.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mit.admissionassistant.R;
import com.mit.admissionassistant.models.AdmissionStep;

import java.util.List;

public class AdmissionStepAdapter extends RecyclerView.Adapter<AdmissionStepAdapter.StepViewHolder> {

    private final Context context;
    private final List<AdmissionStep> stepList;

    public AdmissionStepAdapter(Context context, List<AdmissionStep> stepList) {
        this.context = context;
        this.stepList = stepList;
    }

    @NonNull
    @Override
    public StepViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admission_step, parent, false);
        return new StepViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StepViewHolder holder, int position) {
        AdmissionStep step = stepList.get(position);
        holder.tvStepNumber.setText(String.valueOf(step.getStepNumber()));
        holder.tvStepTitle.setText(step.getTitle());
        holder.tvStepDescription.setText(step.getDescription());
        holder.tvDeadline.setText("Deadline: " + step.getDeadline());
        holder.tvStatusBadge.setText(step.getStatus());
    }

    @Override
    public int getItemCount() {
        return stepList.size();
    }

    static class StepViewHolder extends RecyclerView.ViewHolder {
        TextView tvStepNumber, tvStepTitle, tvStepDescription, tvDeadline, tvStatusBadge;

        public StepViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStepNumber = itemView.findViewById(R.id.tvStepNumber);
            tvStepTitle = itemView.findViewById(R.id.tvStepTitle);
            tvStepDescription = itemView.findViewById(R.id.tvStepDescription);
            tvDeadline = itemView.findViewById(R.id.tvDeadline);
            tvStatusBadge = itemView.findViewById(R.id.tvStatusBadge);
        }
    }
}
