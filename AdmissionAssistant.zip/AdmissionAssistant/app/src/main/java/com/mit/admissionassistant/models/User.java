package com.mit.admissionassistant.models;

public class User {
    private long id;
    private String name;
    private String email;
    private String stream;
    private double percentage;

    public User(long id, String name, String email, String stream, double percentage) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.stream = stream;
        this.percentage = percentage;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getStream() { return stream; }
    public double getPercentage() { return percentage; }

    public void setStream(String stream) { this.stream = stream; }
    public void setPercentage(double percentage) { this.percentage = percentage; }
}
