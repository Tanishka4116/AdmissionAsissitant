package com.mit.admissionassistant.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.mit.admissionassistant.CourseDetailActivity;
import com.mit.admissionassistant.LoginActivity;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.adapters.CourseAdapter;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.utils.PreferenceManager;

import java.util.List;

public class ProfileFragment extends Fragment implements CourseAdapter.OnCourseClickListener {

    private TextView tvProfileName, tvProfileEmail, tvProfileAcademic, tvNoSaved;
    private RecyclerView rvSavedCourses;
    private MaterialButton btnLogout;

    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private CourseAdapter courseAdapter;
    private List<Course> savedCoursesList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        prefManager = new PreferenceManager(requireContext());

        tvProfileName = view.findViewById(R.id.tvProfileName);
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail);
        tvProfileAcademic = view.findViewById(R.id.tvProfileAcademic);
        tvNoSaved = view.findViewById(R.id.tvNoSaved);
        rvSavedCourses = view.findViewById(R.id.rvSavedCourses);
        btnLogout = view.findViewById(R.id.btnLogout);

        rvSavedCourses.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Display user details
        tvProfileName.setText(prefManager.getUserName());
        tvProfileEmail.setText(prefManager.getUserEmail());
        tvProfileAcademic.setText(prefManager.getUserStream() + " Stream • 12th Score: " + prefManager.getUserPercentage() + "%");

        btnLogout.setOnClickListener(v -> performLogout());

        loadSavedCourses();

        return view;
    }

    private void loadSavedCourses() {
        savedCoursesList = dbHelper.getSavedCourses(prefManager.getUserId());
        if (savedCoursesList.isEmpty()) {
            tvNoSaved.setVisibility(View.VISIBLE);
            rvSavedCourses.setVisibility(View.GONE);
        } else {
            tvNoSaved.setVisibility(View.GONE);
            rvSavedCourses.setVisibility(View.VISIBLE);
            courseAdapter = new CourseAdapter(requireContext(), savedCoursesList, this);
            rvSavedCourses.setAdapter(courseAdapter);
        }
    }

    private void performLogout() {
        prefManager.clearSession();
        Toast.makeText(requireContext(), "Signed out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        if (getActivity() != null) {
            getActivity().finish();
        }
    }

    @Override
    public void onCourseClick(Course course) {
        Intent intent = new Intent(requireContext(), CourseDetailActivity.class);
        intent.putExtra("course", course);
        startActivity(intent);
    }

    @Override
    public void onBookmarkClick(Course course, int position) {
        dbHelper.toggleSaveCourse(prefManager.getUserId(), course.getId(), false);
        loadSavedCourses();
        Toast.makeText(requireContext(), "Removed from saved courses", Toast.LENGTH_SHORT).show();
    }
}
