
package com.mit.admissionassistant.fragments;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.adapters.ChatAdapter;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.ChatMessage;
import com.mit.admissionassistant.utils.LlmApiService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatbotFragment extends Fragment {

    private static final String TAG = "ChatbotFragment";

    private RecyclerView rvChat;
    private EditText etChatMessage;
    private ImageView btnSendMessage;
    private MaterialButton chipBtech, chipBca, chipDocs, chipFees;

    private DatabaseHelper dbHelper;
    private ChatAdapter chatAdapter;
    private final List<ChatMessage> messageList = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(
                R.layout.fragment_chatbot,
                container,
                false
        );

        dbHelper = new DatabaseHelper(requireContext());

        rvChat = view.findViewById(R.id.rvChat);
        etChatMessage = view.findViewById(R.id.etChatMessage);
        btnSendMessage = view.findViewById(R.id.btnSendMessage);

        chipBtech = view.findViewById(R.id.chipBtech);
        chipBca = view.findViewById(R.id.chipBca);
        chipDocs = view.findViewById(R.id.chipDocs);
        chipFees = view.findViewById(R.id.chipFees);

        rvChat.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );

        chatAdapter = new ChatAdapter(
                requireContext(),
                messageList
        );

        rvChat.setAdapter(chatAdapter);

        // Initial bot greeting
        if (messageList.isEmpty()) {
            addBotMessage(
                    "Hello! I am your College Admission Assistant. " +
                            "Ask me about courses, eligibility, documents, fees, " +
                            "or admission deadlines."
            );
        }

        // Send button
        btnSendMessage.setOnClickListener(v -> sendMessage());

        // Keyboard Send action
        etChatMessage.setOnEditorActionListener(
                (v, actionId, event) -> {
                    if (actionId == EditorInfo.IME_ACTION_SEND
                            || actionId == EditorInfo.IME_NULL) {
                        sendMessage();
                        return true;
                    }
                    return false;
                }
        );

        // Suggestion chips
        chipBtech.setOnClickListener(v ->
                sendQuery("What is the eligibility for B.Tech?"));

        chipBca.setOnClickListener(v ->
                sendQuery("Can Commerce students apply for BCA?"));

        chipDocs.setOnClickListener(v ->
                sendQuery("What documents are required for application?"));

        chipFees.setOnClickListener(v ->
                sendQuery("What are the tuition fees for B.Tech and BCA?"));

        return view;
    }

    private void sendMessage() {
        String userText = etChatMessage.getText() != null
                ? etChatMessage.getText().toString().trim()
                : "";

        if (userText.isEmpty()) {
            return;
        }

        etChatMessage.setText("");
        hideKeyboard();
        sendQuery(userText);
    }

    private void sendQuery(String queryText) {
        if (queryText == null || queryText.trim().isEmpty()) {
            return;
        }

        String timestamp = new SimpleDateFormat(
                "hh:mm a",
                Locale.getDefault()
        ).format(new Date());

        // Display user message
        messageList.add(
                new ChatMessage(queryText, true, timestamp)
        );

        chatAdapter.notifyItemInserted(messageList.size() - 1);
        rvChat.smoothScrollToPosition(messageList.size() - 1);

        Log.d(TAG, "Sending message to Grok API");

        // Call the live Grok API
        LlmApiService.sendMessage(
                queryText,
                new LlmApiService.ApiCallback() {

                    @Override
                    public void onSuccess(String response) {
                        mainHandler.post(() -> {
                            if (!isAdded()) {
                                return;
                            }

                            if (response == null || response.trim().isEmpty()) {
                                addBotMessage(
                                        "The AI returned an empty response. " +
                                                "Please try again."
                                );
                                return;
                            }

                            Log.d(TAG, "Grok response received successfully");
                            addBotMessage(response.trim());
                        });
                    }

                    @Override
                    public void onError(String error) {
                        mainHandler.post(() -> {
                            if (!isAdded()) {
                                return;
                            }

                            Log.e(TAG, "Gemini API failed: " + error + ". Falling back to local FAQ database.");

                            // Seamless fallback to local SQLite FAQ database
                            String botAnswer = dbHelper.findBestFaqAnswer(queryText);
                            if (botAnswer == null || botAnswer.trim().isEmpty()) {
                                botAnswer = "I couldn't reach the AI service, and no offline answer was found. Please check your internet connection and try again.";
                            }
                            addBotMessage(botAnswer);
                        });
                    }
                }
        );
    }

    private void addBotMessage(String answer) {
        if (!isAdded()) {
            return;
        }

        String timestamp = new SimpleDateFormat(
                "hh:mm a",
                Locale.getDefault()
        ).format(new Date());

        messageList.add(
                new ChatMessage(answer, false, timestamp)
        );

        chatAdapter.notifyItemInserted(messageList.size() - 1);
        rvChat.smoothScrollToPosition(messageList.size() - 1);
    }

    private void hideKeyboard() {
        if (getActivity() != null
                && getActivity().getCurrentFocus() != null) {

            InputMethodManager imm =
                    (InputMethodManager) requireActivity()
                            .getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null) {
                imm.hideSoftInputFromWindow(
                        requireActivity()
                                .getCurrentFocus()
                                .getWindowToken(),
                        0
                );
            }
        }
    }
}
