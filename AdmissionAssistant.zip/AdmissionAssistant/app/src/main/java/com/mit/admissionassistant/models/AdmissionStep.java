package com.mit.admissionassistant.models;

public class

AdmissionStep {
    private int stepNumber;
    private String title;
    private String description;
    private String deadline;
    private String status; // "Upcoming", "Active", "Completed"

    public AdmissionStep(int stepNumber, String title, String description, String deadline, String status) {
        this.stepNumber = stepNumber;
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.status = status;
    }

    public int getStepNumber() { return stepNumber; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getDeadline() { return deadline; }
    public String getStatus() { return status; }
}
