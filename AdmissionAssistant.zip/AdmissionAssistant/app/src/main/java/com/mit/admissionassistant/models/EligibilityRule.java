package com.mit.admissionassistant.models;

import java.io.Serializable;

public class EligibilityRule implements Serializable {
    private long courseId;
    private String courseName;
    private String allowedStreams; // "Science", "Commerce, Arts", "All"
    private double minPercentage;
    private String requiredSubjects;
    private String entranceExamDetails;
    private String additionalCriteria;

    public EligibilityRule(long courseId, String courseName, String allowedStreams, 
                           double minPercentage, String requiredSubjects, 
                           String entranceExamDetails, String additionalCriteria) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.allowedStreams = allowedStreams;
        this.minPercentage = minPercentage;
        this.requiredSubjects = requiredSubjects;
        this.entranceExamDetails = entranceExamDetails;
        this.additionalCriteria = additionalCriteria;
    }

    public long getCourseId() { return courseId; }
    public String getCourseName() { return courseName; }
    public String getAllowedStreams() { return allowedStreams; }
    public double getMinPercentage() { return minPercentage; }
    public String getRequiredSubjects() { return requiredSubjects; }
    public String getEntranceExamDetails() { return entranceExamDetails; }
    public String getAdditionalCriteria() { return additionalCriteria; }
}
