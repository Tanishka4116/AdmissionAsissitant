package com.mit.admissionassistant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.utils.PreferenceManager;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPassword, etPercentage;
    private Spinner spinnerStream;
    private MaterialButton btnRegister;
    private TextView tvLogin;
    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);
        prefManager = new PreferenceManager(this);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etPercentage = findViewById(R.id.etPercentage);
        spinnerStream = findViewById(R.id.spinnerStream);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);

        String[] streams = {"Science", "Commerce", "Arts"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, streams);
        spinnerStream.setAdapter(adapter);

        btnRegister.setOnClickListener(v -> performRegistration());

        tvLogin.setOnClickListener(v -> finish());
    }

    private void performRegistration() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";
        String stream = spinnerStream.getSelectedItem() != null ? spinnerStream.getSelectedItem().toString() : "Science";
        String percStr = etPercentage.getText() != null ? etPercentage.getText().toString().trim() : "";

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || percStr.isEmpty()) {
            Toast.makeText(this, "Please fill in all details", Toast.LENGTH_SHORT).show();
            return;
        }

        double percentage;
        try {
            percentage = Double.parseDouble(percStr);
            if (percentage < 0 || percentage > 100) {
                Toast.makeText(this, "Enter a valid percentage (0 - 100)", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid percentage format", Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = dbHelper.registerUser(name, email, password, stream, percentage);
        if (userId != -1) {
            prefManager.saveUserSession(userId, name, email, stream, percentage);
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Registration failed. Email may already be registered.", Toast.LENGTH_LONG).show();
        }
    }
}
