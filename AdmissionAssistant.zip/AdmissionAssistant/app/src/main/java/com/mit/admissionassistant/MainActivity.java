package com.mit.admissionassistant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mit.admissionassistant.fragments.AdmissionFragment;
import com.mit.admissionassistant.fragments.ChatbotFragment;
import com.mit.admissionassistant.fragments.CoursesFragment;
import com.mit.admissionassistant.fragments.EligibilityFragment;
import com.mit.admissionassistant.fragments.HomeFragment;
import com.mit.admissionassistant.utils.PreferenceManager;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private TextView tvTopUser;
    private ImageView btnTopLogout;
    private PreferenceManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        prefManager = new PreferenceManager(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0); // Keep bottom inset for nav bar
            return insets;
        });

        bottomNav = findViewById(R.id.bottom_navigation);
        tvTopUser = findViewById(R.id.tvTopUser);
        btnTopLogout = findViewById(R.id.btnTopLogout);

        tvTopUser.setText("Logged in as: " + prefManager.getUserName());

        btnTopLogout.setOnClickListener(v -> performLogout());

        // Default to HomeFragment
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                selectedFragment = new HomeFragment();
            } else if (itemId == R.id.nav_courses) {
                selectedFragment = new CoursesFragment();
            } else if (itemId == R.id.nav_eligibility) {
                selectedFragment = new EligibilityFragment();
            } else if (itemId == R.id.nav_admission) {
                selectedFragment = new AdmissionFragment();
            } else if (itemId == R.id.nav_chat) {
                selectedFragment = new ChatbotFragment();
            }

            if (selectedFragment != null) {
                loadFragment(selectedFragment);
                return true;
            }
            return false;
        });
    }

    private void performLogout() {
        prefManager.clearSession();
        Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    public void selectTab(int navMenuItemId) {
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(navMenuItemId);
        }
    }
}
