package com.mit.admissionassistant.models;

import java.io.Serializable;

public class Course implements Serializable {
    private long id;
    private String name;
    private String stream; // Science, Commerce, Arts, All
    private String duration; // e.g. "4 Years", "3 Years"
    private double minPercentage;
    private String description;
    private String subjects;
    private String careerOpportunities;
    private String feeEstimate;
    private boolean isSaved;

    public Course(long id, String name, String stream, String duration, double minPercentage, 
                  String description, String subjects, String careerOpportunities, String feeEstimate, boolean isSaved) {
        this.id = id;
        this.name = name;
        this.stream = stream;
        this.duration = duration;
        this.minPercentage = minPercentage;
        this.description = description;
        this.subjects = subjects;
        this.careerOpportunities = careerOpportunities;
        this.feeEstimate = feeEstimate;
        this.isSaved = isSaved;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getStream() { return stream; }
    public String getDuration() { return duration; }
    public double getMinPercentage() { return minPercentage; }
    public String getDescription() { return description; }
    public String getSubjects() { return subjects; }
    public String getCareerOpportunities() { return careerOpportunities; }
    public String getFeeEstimate() { return feeEstimate; }
    public boolean isSaved() { return isSaved; }

    public void setSaved(boolean saved) { isSaved = saved; }
}
