package com.mit.admissionassistant.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.mit.admissionassistant.CourseDetailActivity;
import com.mit.admissionassistant.MainActivity;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.adapters.CourseAdapter;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.utils.PreferenceManager;

import java.util.List;

public class HomeFragment extends Fragment implements CourseAdapter.OnCourseClickListener {

    private TextView tvWelcomeUser, tvUserStats;
    private EditText etHomeSearch;
    private MaterialCardView cardCourses, cardEligibility, cardAdmission, cardChat;
    private RecyclerView rvFeaturedCourses;
    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private CourseAdapter courseAdapter;
    private List<Course> featuredCourses;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        prefManager = new PreferenceManager(requireContext());

        tvWelcomeUser = view.findViewById(R.id.tvWelcomeUser);
        tvUserStats = view.findViewById(R.id.tvUserStats);
        etHomeSearch = view.findViewById(R.id.etHomeSearch);
        cardCourses = view.findViewById(R.id.cardActionCourses);
        cardEligibility = view.findViewById(R.id.cardActionEligibility);
        cardAdmission = view.findViewById(R.id.cardActionAdmission);
        cardChat = view.findViewById(R.id.cardActionChat);
        rvFeaturedCourses = view.findViewById(R.id.rvFeaturedCourses);

        tvWelcomeUser.setText("Welcome, " + prefManager.getUserName() + "!");
        tvUserStats.setText("Stream: " + prefManager.getUserStream() + " • 12th Score: " + prefManager.getUserPercentage() + "%");

        cardCourses.setOnClickListener(v -> navigateToTab(R.id.nav_courses));
        cardEligibility.setOnClickListener(v -> navigateToTab(R.id.nav_eligibility));
        cardAdmission.setOnClickListener(v -> navigateToTab(R.id.nav_admission));
        cardChat.setOnClickListener(v -> navigateToTab(R.id.nav_chat));

        rvFeaturedCourses.setLayoutManager(new LinearLayoutManager(getContext()));
        loadFeaturedCourses();

        return view;
    }

    private void loadFeaturedCourses() {
        featuredCourses = dbHelper.getCourses("All", "", prefManager.getUserId());
        courseAdapter = new CourseAdapter(requireContext(), featuredCourses, this);
        rvFeaturedCourses.setAdapter(courseAdapter);
    }

    private void navigateToTab(int navId) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).selectTab(navId);
        }
    }

    @Override
    public void onCourseClick(Course course) {
        Intent intent = new Intent(requireContext(), CourseDetailActivity.class);
        intent.putExtra("course", course);
        startActivity(intent);
    }

    @Override
    public void onBookmarkClick(Course course, int position) {
        boolean newSavedState = !course.isSaved();
        course.setSaved(newSavedState);
        dbHelper.toggleSaveCourse(prefManager.getUserId(), course.getId(), newSavedState);
        courseAdapter.notifyItemChanged(position);
    }
}
