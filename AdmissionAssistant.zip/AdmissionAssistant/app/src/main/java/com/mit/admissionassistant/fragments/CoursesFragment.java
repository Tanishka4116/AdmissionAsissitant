package com.mit.admissionassistant.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mit.admissionassistant.CourseDetailActivity;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.adapters.CourseAdapter;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class CoursesFragment extends Fragment implements CourseAdapter.OnCourseClickListener {

    private EditText etCourseSearch;
    private Spinner spinnerStreamFilter;
    private RecyclerView rvCourses;
    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private CourseAdapter courseAdapter;
    private List<Course> courseList = new ArrayList<>();
    private String selectedStream = "All";
    private String searchQuery = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_courses, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        prefManager = new PreferenceManager(requireContext());

        etCourseSearch = view.findViewById(R.id.etCourseSearch);
        spinnerStreamFilter = view.findViewById(R.id.spinnerStreamFilter);
        rvCourses = view.findViewById(R.id.rvCourses);

        rvCourses.setLayoutManager(new LinearLayoutManager(requireContext()));

        String[] streams = {"All", "Science", "Commerce", "Arts"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, streams);
        spinnerStreamFilter.setAdapter(spinnerAdapter);

        spinnerStreamFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedStream = streams[position];
                filterCourses();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        etCourseSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString();
                filterCourses();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        filterCourses();

        return view;
    }

    private void filterCourses() {
        courseList = dbHelper.getCourses(selectedStream, searchQuery, prefManager.getUserId());
        courseAdapter = new CourseAdapter(requireContext(), courseList, this);
        rvCourses.setAdapter(courseAdapter);
    }

    @Override
    public void onCourseClick(Course course) {
        Intent intent = new Intent(requireContext(), CourseDetailActivity.class);
        intent.putExtra("course", course);
        startActivity(intent);
    }

    @Override
    public void onBookmarkClick(Course course, int position) {
        boolean newSavedState = !course.isSaved();
        course.setSaved(newSavedState);
        dbHelper.toggleSaveCourse(prefManager.getUserId(), course.getId(), newSavedState);
        courseAdapter.notifyItemChanged(position);
    }
}
