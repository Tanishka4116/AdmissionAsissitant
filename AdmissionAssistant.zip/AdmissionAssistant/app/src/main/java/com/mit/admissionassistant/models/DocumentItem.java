package com.mit.admissionassistant.models;

public class DocumentItem {
    private String id;
    private String title;
    private String category; // "Academic", "Identity", "Category/Quota"
    private boolean isRequired;
    private boolean isChecked;
    private String uploadedFileName;

    public DocumentItem(String id, String title, String category, boolean isRequired, boolean isChecked) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.isRequired = isRequired;
        this.isChecked = isChecked;
        this.uploadedFileName = null;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public boolean isRequired() { return isRequired; }
    public boolean isChecked() { return isChecked; }
    public String getUploadedFileName() { return uploadedFileName; }

    public void setChecked(boolean checked) { isChecked = checked; }
    public void setUploadedFileName(String uploadedFileName) { this.uploadedFileName = uploadedFileName; }
}
