package com.mit.admissionassistant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.utils.PreferenceManager;

public class CourseDetailActivity extends AppCompatActivity {

    private TextView tvStreamBadge, tvCourseName, tvDuration, tvMinPerc, tvDescription, tvSubjects, tvCareers, tvFeeEstimate;
    private ImageView btnBookmarkDetail;
    private MaterialButton btnCheckCourseEligibility;

    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private Course course;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        dbHelper = new DatabaseHelper(this);
        prefManager = new PreferenceManager(this);

        if (getIntent() != null && getIntent().hasExtra("course")) {
            course = (Course) getIntent().getSerializableExtra("course");
        }

        if (course == null) {
            Toast.makeText(this, "Course details unavailable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvStreamBadge = findViewById(R.id.tvStreamBadge);
        tvCourseName = findViewById(R.id.tvCourseName);
        tvDuration = findViewById(R.id.tvDuration);
        tvMinPerc = findViewById(R.id.tvMinPerc);
        tvDescription = findViewById(R.id.tvDescription);
        tvSubjects = findViewById(R.id.tvSubjects);
        tvCareers = findViewById(R.id.tvCareers);
        tvFeeEstimate = findViewById(R.id.tvFeeEstimate);
        btnBookmarkDetail = findViewById(R.id.btnBookmarkDetail);
        btnCheckCourseEligibility = findViewById(R.id.btnCheckCourseEligibility);

        tvStreamBadge.setText(course.getStream());
        tvCourseName.setText(course.getName());
        tvDuration.setText("Duration: " + course.getDuration());
        tvMinPerc.setText("Min 12th: " + course.getMinPercentage() + "%");
        tvDescription.setText(course.getDescription());
        tvSubjects.setText(course.getSubjects());
        tvCareers.setText(course.getCareerOpportunities());
        tvFeeEstimate.setText("Estimated Fees: " + course.getFeeEstimate());

        updateBookmarkIcon();

        btnBookmarkDetail.setOnClickListener(v -> {
            boolean newSavedState = !course.isSaved();
            course.setSaved(newSavedState);
            dbHelper.toggleSaveCourse(prefManager.getUserId(), course.getId(), newSavedState);
            updateBookmarkIcon();
            Toast.makeText(this, newSavedState ? "Saved to your bookmarks" : "Removed from bookmarks", Toast.LENGTH_SHORT).show();
        });

        btnCheckCourseEligibility.setOnClickListener(v -> {
            Intent intent = new Intent(CourseDetailActivity.this, MainActivity.class);
            intent.putExtra("target_course_id", course.getId());
            startActivity(intent);
            finish();
        });
    }

    private void updateBookmarkIcon() {
        if (course.isSaved()) {
            btnBookmarkDetail.setImageResource(R.drawable.ic_bookmark);
        } else {
            btnBookmarkDetail.setImageResource(R.drawable.ic_bookmark_border);
        }
    }
}
