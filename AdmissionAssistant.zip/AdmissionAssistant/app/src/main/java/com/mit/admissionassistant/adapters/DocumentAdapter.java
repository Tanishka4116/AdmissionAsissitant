package com.mit.admissionassistant.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.models.DocumentItem;

import java.util.List;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.DocViewHolder> {

    public interface OnDocumentActionListener {
        void onCheckChanged(DocumentItem item, boolean isChecked);
        void onUploadClicked(DocumentItem item, int position);
    }

    private final Context context;
    private final List<DocumentItem> documentList;
    private final OnDocumentActionListener listener;

    public DocumentAdapter(Context context, List<DocumentItem> documentList, OnDocumentActionListener listener) {
        this.context = context;
        this.documentList = documentList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public DocViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_document, parent, false);
        return new DocViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DocViewHolder holder, int position) {
        DocumentItem item = documentList.get(position);
        holder.tvDocTitle.setText(item.getTitle());
        holder.tvDocCategory.setText(item.getCategory() + (item.isRequired() ? " • Mandatory" : " • Optional"));

        // Remove listener before setting checked state to avoid triggers during recycle
        holder.cbDocument.setOnCheckedChangeListener(null);
        holder.cbDocument.setChecked(item.isChecked());

        holder.cbDocument.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setChecked(isChecked);
            if (listener != null) {
                listener.onCheckChanged(item, isChecked);
            }
        });

        // Handle Uploaded File Display
        if (item.getUploadedFileName() != null && !item.getUploadedFileName().isEmpty()) {
            holder.tvUploadedFile.setVisibility(View.VISIBLE);
            holder.tvUploadedFile.setText("Uploaded: " + item.getUploadedFileName());
            holder.btnUploadDoc.setText("Replace");
        } else {
            holder.tvUploadedFile.setVisibility(View.GONE);
            holder.btnUploadDoc.setText("Upload");
        }

        holder.btnUploadDoc.setOnClickListener(v -> {
            if (listener != null) {
                listener.onUploadClicked(item, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return documentList.size();
    }

    static class DocViewHolder extends RecyclerView.ViewHolder {
        CheckBox cbDocument;
        TextView tvDocTitle, tvDocCategory, tvUploadedFile;
        MaterialButton btnUploadDoc;

        public DocViewHolder(@NonNull View itemView) {
            super(itemView);
            cbDocument = itemView.findViewById(R.id.cbDocument);
            tvDocTitle = itemView.findViewById(R.id.tvDocTitle);
            tvDocCategory = itemView.findViewById(R.id.tvDocCategory);
            tvUploadedFile = itemView.findViewById(R.id.tvUploadedFile);
            btnUploadDoc = itemView.findViewById(R.id.btnUploadDoc);
        }
    }
}
