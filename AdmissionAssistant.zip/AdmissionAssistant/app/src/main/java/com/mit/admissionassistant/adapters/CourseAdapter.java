package com.mit.admissionassistant.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mit.admissionassistant.R;
import com.mit.admissionassistant.models.Course;

import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {

    public interface OnCourseClickListener {
        void onCourseClick(Course course);
        void onBookmarkClick(Course course, int position);
    }

    private final Context context;
    private final List<Course> courseList;
    private final OnCourseClickListener listener;

    public CourseAdapter(Context context, List<Course> courseList, OnCourseClickListener listener) {
        this.context = context;
        this.courseList = courseList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_course, parent, false);
        return new CourseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course course = courseList.get(position);
        holder.tvCourseName.setText(course.getName());
        holder.tvStreamBadge.setText(course.getStream());
        holder.tvDescription.setText(course.getDescription());
        holder.tvDuration.setText("Duration: " + course.getDuration());
        holder.tvMinPerc.setText("Min 12th: " + course.getMinPercentage() + "%");

        if (course.isSaved()) {
            holder.btnBookmark.setImageResource(R.drawable.ic_bookmark);
        } else {
            holder.btnBookmark.setImageResource(R.drawable.ic_bookmark_border);
        }

        holder.itemView.setOnClickListener(v -> listener.onCourseClick(course));
        holder.btnBookmark.setOnClickListener(v -> listener.onBookmarkClick(course, position));
    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }

    static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView tvStreamBadge, tvCourseName, tvDescription, tvDuration, tvMinPerc;
        ImageView btnBookmark;

        public CourseViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStreamBadge = itemView.findViewById(R.id.tvStreamBadge);
            tvCourseName = itemView.findViewById(R.id.tvCourseName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvDuration = itemView.findViewById(R.id.tvDuration);
            tvMinPerc = itemView.findViewById(R.id.tvMinPerc);
            btnBookmark = itemView.findViewById(R.id.btnBookmark);
        }
    }
}
