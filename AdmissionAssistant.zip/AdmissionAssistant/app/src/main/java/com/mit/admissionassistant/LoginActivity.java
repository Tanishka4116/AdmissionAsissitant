package com.mit.admissionassistant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.User;
import com.mit.admissionassistant.utils.PreferenceManager;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin, btnDemoLogin;
    private TextView tvRegister;
    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        prefManager = new PreferenceManager(this);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnDemoLogin = findViewById(R.id.btnDemoLogin);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> performLogin());

        btnDemoLogin.setOnClickListener(v -> performDemoLogin());

        tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void performLogin() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = dbHelper.authenticateUser(email, password);
        if (user != null) {
            prefManager.saveUserSession(user.getId(), user.getName(), user.getEmail(), user.getStream(), user.getPercentage());
            Toast.makeText(this, "Welcome back, " + user.getName() + "!", Toast.LENGTH_SHORT).show();
            navigateToMain();
        } else {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void performDemoLogin() {
        User user = dbHelper.authenticateUser("demo@college.edu", "demo123");
        if (user != null) {
            prefManager.saveUserSession(user.getId(), user.getName(), user.getEmail(), user.getStream(), user.getPercentage());
            Toast.makeText(this, "Logged in with Demo Student Profile!", Toast.LENGTH_SHORT).show();
            navigateToMain();
        } else {
            // Fallback if demo user wasn't populated
            prefManager.saveUserSession(1, "Alex Morgan", "demo@college.edu", "Science", 82.5);
            Toast.makeText(this, "Logged in with Demo Student Profile!", Toast.LENGTH_SHORT).show();
            navigateToMain();
        }
    }

    private void navigateToMain() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
