package com.mit.admissionassistant.fragments;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mit.admissionassistant.R;
import com.mit.admissionassistant.adapters.AdmissionStepAdapter;
import com.mit.admissionassistant.adapters.DocumentAdapter;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.AdmissionStep;
import com.mit.admissionassistant.models.DocumentItem;
import com.mit.admissionassistant.utils.PreferenceManager;

import java.util.List;
import java.util.Set;

public class AdmissionFragment extends Fragment implements DocumentAdapter.OnDocumentActionListener {

    private RecyclerView rvAdmissionSteps, rvDocuments;
    private TextView tvDocProgress;

    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private List<DocumentItem> documentList;
    private DocumentAdapter documentAdapter;

    private int pendingUploadPosition = -1;
    private String pendingUploadDocId = null;

    private final ActivityResultLauncher<Intent> filePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null && pendingUploadDocId != null && pendingUploadPosition != -1) {
                        String fileName = getFileNameFromUri(uri);
                        prefManager.saveUploadedDocument(pendingUploadDocId, fileName);

                        if (pendingUploadPosition < documentList.size()) {
                            DocumentItem item = documentList.get(pendingUploadPosition);
                            item.setUploadedFileName(fileName);
                            item.setChecked(true);
                            documentAdapter.notifyItemChanged(pendingUploadPosition);
                        }

                        updateProgressCounter();
                        Toast.makeText(requireContext(), "Document uploaded: " + fileName, Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admission, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        prefManager = new PreferenceManager(requireContext());

        rvAdmissionSteps = view.findViewById(R.id.rvAdmissionSteps);
        rvDocuments = view.findViewById(R.id.rvDocuments);
        tvDocProgress = view.findViewById(R.id.tvDocProgress);

        rvAdmissionSteps.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvDocuments.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Load Admission Steps
        List<AdmissionStep> steps = dbHelper.getAdmissionSteps();
        AdmissionStepAdapter stepAdapter = new AdmissionStepAdapter(requireContext(), steps);
        rvAdmissionSteps.setAdapter(stepAdapter);

        // Load Documents and restore checkbox state & uploaded file name from PreferenceManager
        loadDocumentsWithState();

        return view;
    }

    private void loadDocumentsWithState() {
        documentList = dbHelper.getDocuments();
        Set<String> savedCheckedIds = prefManager.getCheckedDocuments();

        int checkedCount = 0;
        for (DocumentItem item : documentList) {
            boolean isChecked = savedCheckedIds.contains(item.getId());
            item.setChecked(isChecked);

            String uploadedFileName = prefManager.getUploadedDocument(item.getId());
            if (uploadedFileName != null) {
                item.setUploadedFileName(uploadedFileName);
                item.setChecked(true);
            }

            if (item.isChecked()) checkedCount++;
        }

        tvDocProgress.setText(checkedCount + " / " + documentList.size() + " Checked");

        documentAdapter = new DocumentAdapter(requireContext(), documentList, this);
        rvDocuments.setAdapter(documentAdapter);
    }

    private void updateProgressCounter() {
        int checkedCount = 0;
        for (DocumentItem doc : documentList) {
            if (doc.isChecked()) checkedCount++;
        }
        tvDocProgress.setText(checkedCount + " / " + documentList.size() + " Checked");
    }

    @Override
    public void onCheckChanged(DocumentItem item, boolean isChecked) {
        prefManager.setDocumentChecked(item.getId(), isChecked);
        updateProgressCounter();
    }

    @Override
    public void onUploadClicked(DocumentItem item, int position) {
        pendingUploadPosition = position;
        pendingUploadDocId = item.getId();

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
        filePickerLauncher.launch(Intent.createChooser(intent, "Select Document File"));
    }

    private String getFileNameFromUri(Uri uri) {
        String result = null;
        if (uri.getScheme() != null && uri.getScheme().equals("content")) {
            try (Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index != -1) {
                        result = cursor.getString(index);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) {
                    result = result.substring(cut + 1);
                }
            }
        }
        return result != null ? result : "UploadedDocument.pdf";
    }
}
