package com.mit.admissionassistant.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.mit.admissionassistant.R;
import com.mit.admissionassistant.db.DatabaseHelper;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.models.EligibilityRule;
import com.mit.admissionassistant.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class EligibilityFragment extends Fragment {

    private Spinner spinnerCourseSelect, spinnerUserStream;
    private EditText etUserPercentage, etEntranceScore;
    private MaterialButton btnCheckEligibility;

    private MaterialCardView cardEligibilityResult;
    private TextView tvStatusBadge, tvResultExplanation, tvScoreComparison, tvStreamComparison, tvEntranceInfo;

    private DatabaseHelper dbHelper;
    private PreferenceManager prefManager;
    private List<Course> allCourses = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_eligibility, container, false);

        dbHelper = new DatabaseHelper(requireContext());
        prefManager = new PreferenceManager(requireContext());

        spinnerCourseSelect = view.findViewById(R.id.spinnerCourseSelect);
        spinnerUserStream = view.findViewById(R.id.spinnerUserStream);
        etUserPercentage = view.findViewById(R.id.etUserPercentage);
        etEntranceScore = view.findViewById(R.id.etEntranceScore);
        btnCheckEligibility = view.findViewById(R.id.btnCheckEligibility);

        cardEligibilityResult = view.findViewById(R.id.cardEligibilityResult);
        tvStatusBadge = view.findViewById(R.id.tvStatusBadge);
        tvResultExplanation = view.findViewById(R.id.tvResultExplanation);
        tvScoreComparison = view.findViewById(R.id.tvScoreComparison);
        tvStreamComparison = view.findViewById(R.id.tvStreamComparison);
        tvEntranceInfo = view.findViewById(R.id.tvEntranceInfo);

        // Populate User Details from PreferenceManager by default
        etUserPercentage.setText(String.valueOf(prefManager.getUserPercentage()));

        String[] streams = {"Science", "Commerce", "Arts"};
        ArrayAdapter<String> streamAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, streams);
        spinnerUserStream.setAdapter(streamAdapter);

        // Select user stream index
        String userStream = prefManager.getUserStream();
        for (int i = 0; i < streams.length; i++) {
            if (streams[i].equalsIgnoreCase(userStream)) {
                spinnerUserStream.setSelection(i);
                break;
            }
        }

        // Populate Course Spinner from DB
        allCourses = dbHelper.getCourses("All", "", prefManager.getUserId());
        List<String> courseNames = new ArrayList<>();
        for (Course c : allCourses) {
            courseNames.add(c.getName());
        }
        ArrayAdapter<String> courseAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, courseNames);
        spinnerCourseSelect.setAdapter(courseAdapter);

        btnCheckEligibility.setOnClickListener(v -> evaluateEligibility());

        return view;
    }

    private void evaluateEligibility() {
        if (allCourses.isEmpty()) return;

        int selectedCourseIndex = spinnerCourseSelect.getSelectedItemPosition();
        if (selectedCourseIndex < 0 || selectedCourseIndex >= allCourses.size()) return;

        Course selectedCourse = allCourses.get(selectedCourseIndex);
        EligibilityRule rule = dbHelper.getEligibilityRuleForCourse(selectedCourse.getId());

        String userStream = spinnerUserStream.getSelectedItem() != null ? spinnerUserStream.getSelectedItem().toString() : "Science";
        String scoreStr = etUserPercentage.getText() != null ? etUserPercentage.getText().toString().trim() : "";
        String entranceScore = etEntranceScore.getText() != null ? etEntranceScore.getText().toString().trim() : "";

        if (scoreStr.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter your 12th percentage", Toast.LENGTH_SHORT).show();
            return;
        }

        double userPercentage;
        try {
            userPercentage = Double.parseDouble(scoreStr);
        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "Invalid percentage format", Toast.LENGTH_SHORT).show();
            return;
        }

        cardEligibilityResult.setVisibility(View.VISIBLE);

        double reqPercentage = rule != null ? rule.getMinPercentage() : selectedCourse.getMinPercentage();
        String allowedStreams = rule != null ? rule.getAllowedStreams() : selectedCourse.getStream();

        boolean isStreamMatches = allowedStreams.equalsIgnoreCase("All") ||
                allowedStreams.toLowerCase().contains(userStream.toLowerCase());

        boolean isScoreMatches = userPercentage >= reqPercentage;

        if (isStreamMatches && isScoreMatches) {
            tvStatusBadge.setText("ELIGIBLE");
            tvStatusBadge.setTextColor(getResources().getColor(R.color.green_success, null));
            tvStatusBadge.getBackground().setTint(0xFFDCFCE7); // Soft light green
            cardEligibilityResult.setStrokeColor(getResources().getColor(R.color.green_success, null));

            tvResultExplanation.setText("Congratulations! You satisfy all core academic requirements for " + selectedCourse.getName() + ".");
        } else if (!isStreamMatches) {
            tvStatusBadge.setText("INELIGIBLE");
            tvStatusBadge.setTextColor(getResources().getColor(R.color.red_error, null));
            tvStatusBadge.getBackground().setTint(0xFFFEE2E2); // Soft light red
            cardEligibilityResult.setStrokeColor(getResources().getColor(R.color.red_error, null));

            tvResultExplanation.setText("Stream Mismatch: " + selectedCourse.getName() + " requires " + allowedStreams + " background.");
        } else {
            tvStatusBadge.setText("INELIGIBLE");
            tvStatusBadge.setTextColor(getResources().getColor(R.color.red_error, null));
            tvStatusBadge.getBackground().setTint(0xFFFEE2E2);
            cardEligibilityResult.setStrokeColor(getResources().getColor(R.color.red_error, null));

            tvResultExplanation.setText("Minimum Score Requirement Not Met: Your score (" + userPercentage + "%) is below the required " + reqPercentage + "%.");
        }

        tvScoreComparison.setText("• Marks: Your Score (" + userPercentage + "%) vs Cutoff (" + reqPercentage + "%) -> " + (isScoreMatches ? "PASSED" : "FAILED"));
        tvStreamComparison.setText("• Stream: Your Stream (" + userStream + ") vs Allowed (" + allowedStreams + ") -> " + (isStreamMatches ? "MATCHED" : "UNMATCHED"));

        if (rule != null && rule.getEntranceExamDetails() != null) {
            tvEntranceInfo.setText("• Entrance & Prereqs: " + rule.getEntranceExamDetails() + " (" + rule.getRequiredSubjects() + ")");
        } else {
            tvEntranceInfo.setText("• Entrance: " + (!entranceScore.isEmpty() ? "Entrance score recorded (" + entranceScore + ")" : "Merit/Admission Test based."));
        }
    }
}
