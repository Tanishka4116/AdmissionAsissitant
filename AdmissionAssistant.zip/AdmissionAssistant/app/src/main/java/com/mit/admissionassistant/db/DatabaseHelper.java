package com.mit.admissionassistant.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.mit.admissionassistant.models.AdmissionStep;
import com.mit.admissionassistant.models.Course;
import com.mit.admissionassistant.models.DocumentItem;
import com.mit.admissionassistant.models.EligibilityRule;
import com.mit.admissionassistant.models.User;
import com.mit.admissionassistant.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "admission_assistant.db";
    private static final int DATABASE_VERSION = 2; // Upgraded to v2 for safe migration

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_COURSES = "courses";
    public static final String TABLE_RULES = "eligibility_rules";
    public static final String TABLE_STEPS = "admission_steps";
    public static final String TABLE_DOCUMENTS = "documents";
    public static final String TABLE_SAVED = "saved_courses";
    public static final String TABLE_FAQS = "faqs";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users Table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "email TEXT UNIQUE, " +
                "password TEXT, " +
                "stream TEXT, " +
                "percentage REAL)");

        // Courses Table
        db.execSQL("CREATE TABLE " + TABLE_COURSES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "stream TEXT, " +
                "duration TEXT, " +
                "min_percentage REAL, " +
                "description TEXT, " +
                "subjects TEXT, " +
                "career_opportunities TEXT, " +
                "fee_estimate TEXT)");

        // Eligibility Rules Table
        db.execSQL("CREATE TABLE " + TABLE_RULES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "course_id INTEGER, " +
                "allowed_streams TEXT, " +
                "min_percentage REAL, " +
                "required_subjects TEXT, " +
                "entrance_details TEXT, " +
                "additional_criteria TEXT)");

        // Admission Steps Table
        db.execSQL("CREATE TABLE " + TABLE_STEPS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "step_number INTEGER, " +
                "title TEXT, " +
                "description TEXT, " +
                "deadline TEXT, " +
                "status TEXT)");

        // Documents Checklist Table
        db.execSQL("CREATE TABLE " + TABLE_DOCUMENTS + " (" +
                "id TEXT PRIMARY KEY, " +
                "title TEXT, " +
                "category TEXT, " +
                "is_required INTEGER)");

        // Saved Courses Table
        db.execSQL("CREATE TABLE " + TABLE_SAVED + " (" +
                "user_id INTEGER, " +
                "course_id INTEGER, " +
                "PRIMARY KEY (user_id, course_id))");

        // FAQs Table
        db.execSQL("CREATE TABLE " + TABLE_FAQS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT, " +
                "question TEXT, " +
                "answer TEXT, " +
                "keywords TEXT)");

        // Seed initial data
        seedData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Safe Migration: Add missing Science, Commerce, and Arts courses idempotently without wiping user tables
            seedCoursesAndRules(db);
            seedFaqs(db);
        } else {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_RULES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_STEPS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOCUMENTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_SAVED);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAQS);
            onCreate(db);
        }
    }

    private void seedData(SQLiteDatabase db) {
        // Seed Demo User (if not existing)
        String hashedPassword = SecurityUtils.hashPassword("demo123");
        db.execSQL("INSERT OR IGNORE INTO " + TABLE_USERS + " (name, email, password, stream, percentage) VALUES " +
                "('Alex Morgan', 'demo@college.edu', '" + hashedPassword + "', 'Science', 82.5)");

        // Seed Courses & Rules
        seedCoursesAndRules(db);

        // Seed Admission Steps
        db.execSQL("INSERT OR IGNORE INTO " + TABLE_STEPS + " (step_number, title, description, deadline, status) VALUES " +
                "(1, 'Online Registration', 'Fill out candidate profile and register on university portal.', 'June 15, 2026', 'Active'), " +
                "(2, 'Document Upload', 'Upload clear scanned copies of marksheets, photos, ID, and certificates.', 'June 25, 2026', 'Upcoming'), " +
                "(3, 'Entrance Test / Merit Ranking', 'Appear for entrance exam or check cut-off merit list publication.', 'July 05, 2026', 'Upcoming'), " +
                "(4, 'Counselling & Seat Allotment', 'Select program preferences and confirm allocated seat.', 'July 15, 2026', 'Upcoming'), " +
                "(5, 'Fee Payment & Verification', 'Pay seat acceptance fee and report for document verification.', 'July 25, 2026', 'Upcoming')");

        // Seed Documents
        db.execSQL("INSERT OR IGNORE INTO " + TABLE_DOCUMENTS + " (id, title, category, is_required) VALUES " +
                "('DOC_10TH', '10th Marksheet & Passing Certificate', 'Academic', 1), " +
                "('DOC_12TH', '12th Marksheet / Admit Card', 'Academic', 1), " +
                "('DOC_ENTRANCE', 'Entrance Exam Scorecard (JEE / CUET)', 'Academic', 0), " +
                "('DOC_ID', 'Government ID Proof (Aadhaar / Passport)', 'Identity', 1), " +
                "('DOC_PHOTO', 'Passport Size Photographs (4 Copies)', 'Identity', 1), " +
                "('DOC_TC', 'Transfer & Migration Certificate from School', 'Academic', 1), " +
                "('DOC_CATEGORY', 'Category / Caste / Quota Certificate (If applicable)', 'Category/Quota', 0)");

        // Seed FAQs
        seedFaqs(db);
    }

    private void seedCoursesAndRules(SQLiteDatabase db) {
        // --- SCIENCE COURSES ---
        insertCourseWithRuleIfNotExists(db,
                "B.Tech Computer Science & Engineering",
                "Science", "4 Years", 60.0,
                "Comprehensive 4-year degree covering software engineering, AI, algorithms, web dev, and computer networks.",
                "Data Structures, Algorithms, DBMS, Operating Systems, Computer Architecture, AI & ML",
                "Software Engineer, Full Stack Developer, Data Scientist, Systems Architect, AI Specialist",
                "₹1,20,000 / year (Sample)",
                "Science", 60.0, "Physics, Chemistry, Mathematics (PCM)",
                "JEE Main / State CET Score required.",
                "Minimum 50% marks in Mathematics individually.");

        insertCourseWithRuleIfNotExists(db,
                "B.Sc. Data Science & AI",
                "Science", "3 Years", 55.0,
                "Specialized degree in data analytics, machine learning algorithms, statistical modeling, and big data systems.",
                "Python Programming, Calculus & Linear Algebra, Probability, Machine Learning, Data Visualization",
                "Data Analyst, BI Developer, ML Engineer, Quantitative Analyst, Research Assistant",
                "₹85,000 / year (Sample)",
                "Science", 55.0, "Mathematics and Statistics/Physics in 12th grade",
                "Merit Based + Math Assessment",
                "Strong foundation in High School Mathematics is required.");

        // --- OPEN / MULTI-STREAM COURSES ---
        insertCourseWithRuleIfNotExists(db,
                "BCA (Bachelor of Computer Applications)",
                "All", "3 Years", 50.0,
                "Undergraduate program focusing on computer applications, software design, web technologies, and database management.",
                "C++, Java, Python, Web Development, SQL, Networking, Software Engineering",
                "Web Developer, App Developer, System Analyst, Database Administrator, Tech Support Lead",
                "₹65,000 / year (Sample)",
                "Science, Commerce, Arts", 50.0, "English and Mathematics/Computer Studies in 12th grade",
                "University Entrance Test or Merit Based",
                "Open to all streams with basic computer aptitude.");

        insertCourseWithRuleIfNotExists(db,
                "BBA (Bachelor of Business Administration)",
                "All", "3 Years", 50.0,
                "Professional degree developing business management, leadership, marketing, finance, and entrepreneurial skills.",
                "Principles of Management, Business Economics, Financial Accounting, Marketing, HR Management",
                "Business Analyst, Marketing Executive, HR Specialist, Operations Manager, Entrepreneur",
                "₹75,000 / year (Sample)",
                "Science, Commerce, Arts", 50.0, "English in 12th grade",
                "Management Aptitude Test / Merit Based",
                "Group discussion and personal interview may be conducted.");

        // --- COMMERCE COURSES ---
        insertCourseWithRuleIfNotExists(db,
                "B.Com (Bachelor of Commerce)",
                "Commerce", "3 Years", 50.0,
                "Foundational program in corporate accounting, business trade, commercial laws, taxation, and economic principles.",
                "Financial Accounting, Business Law, Company Law, Economics, Corporate Tax, Business Communication",
                "Accountant, Tax Assistant, Financial Consultant, Audit Associate, Business Analyst",
                "₹50,000 / year (Sample)",
                "Commerce, Science", 50.0, "Accountancy, Business Studies or Economics in 12th grade",
                "Merit Based / CUET",
                "Minimum 50% aggregate score in 12th grade.");

        insertCourseWithRuleIfNotExists(db,
                "B.Com Accounting & Finance (BAF)",
                "Commerce", "3 Years", 55.0,
                "Specialized degree focusing on advanced auditing, financial reporting, managerial accounting, and cost management.",
                "Advanced Financial Accounting, Cost Accounting, Management Accounting, Taxation, Auditing, Financial Management",
                "Financial Accountant, Internal Auditor, Cost Estimator, Tax Specialist, Corporate Finance Associate",
                "₹55,000 / year (Sample)",
                "Commerce", 55.0, "Accountancy and Mathematics/Statistics in 12th grade",
                "Merit Based / Entrance Exam",
                "Commerce stream candidates with strong math proficiency.");

        insertCourseWithRuleIfNotExists(db,
                "B.Com Banking & Insurance (BBI)",
                "Commerce", "3 Years", 50.0,
                "Professional course focused on banking laws, risk management, insurance underwriting, and financial services.",
                "Principles of Banking, Risk Management, Insurance Law, Financial Markets, Credit Management, Investment Analysis",
                "Banking Executive, Insurance Underwriter, Credit Analyst, Risk Management Officer, Loan Consultant",
                "₹52,000 / year (Sample)",
                "Commerce, Science", 50.0, "Commerce or Science stream in 12th grade",
                "Merit Based / University Test",
                "Knowledge of basic financial mathematics.");

        insertCourseWithRuleIfNotExists(db,
                "B.Com Financial Markets (BFM)",
                "Commerce", "3 Years", 50.0,
                "Specialized program in stock markets, equity trading, securities analysis, commodities, and portfolio management.",
                "Capital Markets, Equity Research, Forex Management, Portfolio Analysis, Financial Derivatives, Securities Law",
                "Stock Trader, Equity Research Analyst, Portfolio Manager, Commodity Broker, Financial Adviser",
                "₹54,000 / year (Sample)",
                "Commerce, Science", 50.0, "12th grade Commerce or Science",
                "Merit Based",
                "Analytical skills and interest in stock markets.");

        insertCourseWithRuleIfNotExists(db,
                "BMS (Bachelor of Management Studies)",
                "Commerce", "3 Years", 50.0,
                "Comprehensive degree covering managerial decision making, strategic planning, marketing dynamics, and organizational leadership.",
                "Managerial Economics, Organizational Behavior, Strategic Management, Marketing Research, E-Commerce",
                "Management Trainee, Brand Manager, Business Development Officer, Operations Coordinator, Management Consultant",
                "₹60,000 / year (Sample)",
                "Commerce, Science, Arts", 50.0, "English and Mathematics/Business Math in 12th grade",
                "Common Entrance Test / Merit",
                "Extracurricular leadership and communication skills.");

        insertCourseWithRuleIfNotExists(db,
                "Economics (B.A. / B.Sc. Economics)",
                "Commerce", "3 Years", 50.0,
                "Analytical degree studying microeconomics, macroeconomics, econometrics, public policy, and financial systems.",
                "Microeconomic Analysis, Macroeconomics, Econometrics, Mathematical Economics, International Trade, Public Finance",
                "Economist, Data & Policy Analyst, Risk Analyst, Research Officer, Financial Consultant",
                "₹45,000 / year (Sample)",
                "Commerce, Science, Arts", 50.0, "Mathematics or Economics in 12th grade",
                "CUET / Merit Based",
                "Mandatory background in High School Mathematics or Economics.");

        // --- ARTS / HUMANITIES COURSES ---
        insertCourseWithRuleIfNotExists(db,
                "B.A. English",
                "Arts", "3 Years", 50.0,
                "In-depth exploration of British, American, and global literature, linguistics, literary theory, and creative writing.",
                "English Literature, World Classics, Literary Theory, Phonetics & Linguistics, Creative Writing, Translation Studies",
                "Content Writer, Editor, Publisher, Journalist, Public Relations Specialist, Educator",
                "₹35,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "Minimum 55% in English in 12th grade",
                "Merit Based / CUET",
                "Strong reading comprehension and written communication.");

        insertCourseWithRuleIfNotExists(db,
                "B.A. Psychology",
                "Arts", "3 Years", 50.0,
                "Fascinating study of human behavior, cognitive processes, developmental psychology, clinical assessment, and mental health.",
                "General Psychology, Cognitive Psychology, Social Behavior, Abnormal Psychology, Counseling Techniques, Research Methods",
                "Counseling Assistant, HR Specialist, Behavioral Analyst, Child Guidance Consultant, Clinical Researcher",
                "₹40,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade aggregate minimum 50%",
                "Merit Based / CUET",
                "Open to all streams with empathy and analytical mindset.");

        insertCourseWithRuleIfNotExists(db,
                "B.A. History",
                "Arts", "3 Years", 50.0,
                "Comprehensive study of ancient, medieval, and modern world civilizations, heritage preservation, and historical research.",
                "Ancient World Civilizations, History of India, European History, Historiography, Archival Management, Heritage Studies",
                "Historian, Archival Specialist, Museum Curator, Civil Services Candidate, Research Officer",
                "₹35,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade in any stream",
                "Merit Based",
                "Analytical reading and essay writing skills.");

        insertCourseWithRuleIfNotExists(db,
                "B.A. Political Science",
                "Arts", "3 Years", 50.0,
                "In-depth analysis of political theories, constitutional framework, international relations, governance, and public policy.",
                "Indian Political System, Political Thought, Comparative Politics, International Relations, Public Administration",
                "Policy Analyst, Political Consultant, Civil Servant, Diplomat, Legal Consultant",
                "₹35,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade in any stream",
                "Merit Based / CUET",
                "Interest in current affairs and public governance.");

        insertCourseWithRuleIfNotExists(db,
                "B.A. Sociology",
                "Arts", "3 Years", 50.0,
                "Systematic study of social structures, cultural institutions, community development, social policy, and human relationships.",
                "Introduction to Sociology, Social Anthropology, Indian Society, Social Statistics, Gender Studies, Urban Sociology",
                "Social Worker, Community Organizer, Market Researcher, NGO Program Coordinator, HR Associate",
                "₹35,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade in any stream",
                "Merit Based",
                "Interest in social issues and field research.");

        insertCourseWithRuleIfNotExists(db,
                "B.A. Geography",
                "Arts", "3 Years", 50.0,
                "Study of physical landforms, climate science, human geography, environmental management, GIS mapping, and remote sensing.",
                "Physical Geography, Geomorphology, Cartography, GIS & Remote Sensing, Environmental Studies, Population Geography",
                "GIS Specialist, Cartographer, Environmental Consultant, Urban Planner, Weather Analyst",
                "₹38,000 / year (Sample)",
                "Arts, Science", 50.0, "Geography or Science in 12th grade",
                "Merit Based",
                "Spatial intelligence and interest in map technologies.");

        insertCourseWithRuleIfNotExists(db,
                "Journalism and Mass Communication",
                "Arts", "3 Years", 50.0,
                "Dynamic professional program covering print journalism, TV broadcasting, digital media, advertising, and public relations.",
                "Media Reporting, News Editing, Broadcast Journalism, Digital Media Production, Advertising, Public Relations, Film Studies",
                "News Reporter, TV Anchor, Content Producer, Media Planner, PR Manager, Digital Marketer",
                "₹60,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "English in 12th grade",
                "Media Aptitude Test / Interview",
                "Excellent oral and written communication skills.");

        insertCourseWithRuleIfNotExists(db,
                "Bachelor of Social Work (BSW)",
                "Arts", "3 Years", 50.0,
                "Action-oriented degree training professionals in social welfare, community rehabilitation, healthcare, and humanitarian development.",
                "Social Work Concepts, Human Rights, Community Organization, Social Legislation, Counseling, Fieldwork Practicum",
                "Social Work Officer, NGO Manager, Community Development Officer, Healthcare Social Worker, Rehabilitation Officer",
                "₹42,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade in any stream",
                "Merit Based / Personal Interview",
                "Commitment to community service and field activities.");

        insertCourseWithRuleIfNotExists(db,
                "Bachelor of Fine Arts (BFA)",
                "Arts", "4 Years", 50.0,
                "Creative degree specializing in visual arts, painting, sculpture, applied art, graphic design, and digital illustration.",
                "Drawing & Painting, Sculpture, Applied Art, History of Art, Graphic Design, Digital Illustration, Photography",
                "Graphic Designer, Illustrator, Visual Artist, Art Director, Animator, Exhibition Designer",
                "₹50,000 / year (Sample)",
                "Arts, Science, Commerce", 50.0, "12th grade in any stream",
                "Practical Drawing / Portfolio Test",
                "Creative artistic portfolio and design test score.");
    }

    private void seedFaqs(SQLiteDatabase db) {
        insertFaqIfNotExists(db, "Eligibility", "What is the eligibility criteria for B.Tech?",
                "B.Tech requires passing 12th grade with Science stream (Physics, Chemistry, Math), a minimum score of 60%, and a valid entrance exam score (JEE or State CET).",
                "btech eligibility criteria 12th percentage pcm jee science qualification requirements");

        insertFaqIfNotExists(db, "Eligibility", "Can Commerce or Arts students apply for BCA?",
                "Yes! BCA is open to Science, Commerce, and Arts students, provided they achieved at least 50% in 12th grade with English.",
                "bca commerce arts stream eligibility percentage requirements apply qualification");

        insertFaqIfNotExists(db, "Eligibility", "Which courses are available after Commerce?",
                "Popular courses after Commerce include B.Com (Honours), B.Com Accounting & Finance (BAF), B.Com Banking & Insurance (BBI), B.Com Financial Markets (BFM), BBA, BMS, and Economics.",
                "commerce courses available options bcom bba bms baf bbi bfm economics study stream");

        insertFaqIfNotExists(db, "Eligibility", "What can I study after Arts?",
                "After Arts / Humanities, you can study B.A. English, B.A. Psychology, B.A. History, B.A. Political Science, B.A. Sociology, Journalism & Mass Communication, BSW (Social Work), BFA (Fine Arts), as well as BCA and BBA.",
                "arts humanities courses study options ba english psychology history political science journalism bsw bfa bca bba stream");

        insertFaqIfNotExists(db, "Admission", "What documents are required for application submission?",
                "You need your 10th & 12th marksheets, Government ID proof (Aadhaar), passport photo, Transfer Certificate, and entrance scorecard (if applicable).",
                "documents required list application 10th 12th marksheet id tc proof certificates upload");

        insertFaqIfNotExists(db, "Fees", "What are the tuition fees for B.Tech and BCA?",
                "Sample fees: B.Tech is approx ₹1,20,000/year, BCA is approx ₹65,000/year, BBA is ₹75,000/year, and B.Com is ₹50,000/year. Fees vary by program.",
                "fees tuition cost btech bca bba bcom payment amount price structures money");

        insertFaqIfNotExists(db, "Dates", "What is the last date to register for admission?",
                "Online registration deadline is June 15, 2026, followed by document upload till June 25, 2026.",
                "date deadline last register registration portal schedule counselling schedule timing when");
    }

    private void insertCourseWithRuleIfNotExists(SQLiteDatabase db, String name, String stream, String duration, double minPerc,
                                                String desc, String subjects, String careers, String fee,
                                                String allowedStreams, double ruleMinPerc, String reqSubjects,
                                                String entranceDetails, String additionalCriteria) {
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_COURSES + " WHERE name = ?", new String[]{name});
        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            return; // Course already exists, skip duplicate insertion
        }
        if (cursor != null) cursor.close();

        ContentValues cvCourse = new ContentValues();
        cvCourse.put("name", name);
        cvCourse.put("stream", stream);
        cvCourse.put("duration", duration);
        cvCourse.put("min_percentage", minPerc);
        cvCourse.put("description", desc);
        cvCourse.put("subjects", subjects);
        cvCourse.put("career_opportunities", careers);
        cvCourse.put("fee_estimate", fee);
        long courseId = db.insert(TABLE_COURSES, null, cvCourse);

        ContentValues cvRule = new ContentValues();
        cvRule.put("course_id", courseId);
        cvRule.put("allowed_streams", allowedStreams);
        cvRule.put("min_percentage", ruleMinPerc);
        cvRule.put("required_subjects", reqSubjects);
        cvRule.put("entrance_details", entranceDetails);
        cvRule.put("additional_criteria", additionalCriteria);
        db.insert(TABLE_RULES, null, cvRule);
    }

    private void insertFaqIfNotExists(SQLiteDatabase db, String category, String question, String answer, String keywords) {
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_FAQS + " WHERE question = ?", new String[]{question});
        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            return;
        }
        if (cursor != null) cursor.close();

        ContentValues cv = new ContentValues();
        cv.put("category", category);
        cv.put("question", question);
        cv.put("answer", answer);
        cv.put("keywords", keywords);
        db.insert(TABLE_FAQS, null, cv);
    }

    // User Operations
    public long registerUser(String name, String email, String password, String stream, double percentage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("email", email.toLowerCase().trim());
        cv.put("password", SecurityUtils.hashPassword(password));
        cv.put("stream", stream);
        cv.put("percentage", percentage);
        return db.insert(TABLE_USERS, null, cv);
    }

    public User authenticateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String hashedPassword = SecurityUtils.hashPassword(password);
        Cursor cursor = db.query(TABLE_USERS, null, "email = ? AND password = ?",
                new String[]{email.toLowerCase().trim(), hashedPassword}, null, null, null);

        User user = null;
        if (cursor != null && cursor.moveToFirst()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            String userEmail = cursor.getString(cursor.getColumnIndexOrThrow("email"));
            String stream = cursor.getString(cursor.getColumnIndexOrThrow("stream"));
            double percentage = cursor.getDouble(cursor.getColumnIndexOrThrow("percentage"));
            user = new User(id, name, userEmail, stream, percentage);
            cursor.close();
        }
        return user;
    }

    // Course Operations
    public List<Course> getCourses(String streamFilter, String searchQuery, long userId) {
        List<Course> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder sql = new StringBuilder("SELECT * FROM " + TABLE_COURSES + " WHERE 1=1");
        List<String> args = new ArrayList<>();

        if (streamFilter != null && !streamFilter.isEmpty() && !streamFilter.equalsIgnoreCase("All")) {
            sql.append(" AND (stream = ? OR stream = 'All')");
            args.add(streamFilter.trim());
        }

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            sql.append(" AND (name LIKE ? OR description LIKE ? OR subjects LIKE ? OR stream LIKE ?)");
            String queryArg = "%" + searchQuery.trim() + "%";
            args.add(queryArg);
            args.add(queryArg);
            args.add(queryArg);
            args.add(queryArg);
        }

        sql.append(" ORDER BY name ASC");

        Cursor cursor = db.rawQuery(sql.toString(), args.toArray(new String[0]));
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String stream = cursor.getString(cursor.getColumnIndexOrThrow("stream"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration"));
                double minPerc = cursor.getDouble(cursor.getColumnIndexOrThrow("min_percentage"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String subjects = cursor.getString(cursor.getColumnIndexOrThrow("subjects"));
                String careers = cursor.getString(cursor.getColumnIndexOrThrow("career_opportunities"));
                String fee = cursor.getString(cursor.getColumnIndexOrThrow("fee_estimate"));

                boolean isSaved = isCourseSaved(userId, id);
                list.add(new Course(id, name, stream, duration, minPerc, desc, subjects, careers, fee, isSaved));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public List<Course> getSavedCourses(long userId) {
        List<Course> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT c.* FROM " + TABLE_COURSES + " c " +
                "INNER JOIN " + TABLE_SAVED + " s ON c.id = s.course_id " +
                "WHERE s.user_id = ? ORDER BY c.name ASC";
        Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(userId)});
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String stream = cursor.getString(cursor.getColumnIndexOrThrow("stream"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration"));
                double minPerc = cursor.getDouble(cursor.getColumnIndexOrThrow("min_percentage"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String subjects = cursor.getString(cursor.getColumnIndexOrThrow("subjects"));
                String careers = cursor.getString(cursor.getColumnIndexOrThrow("career_opportunities"));
                String fee = cursor.getString(cursor.getColumnIndexOrThrow("fee_estimate"));
                list.add(new Course(id, name, stream, duration, minPerc, desc, subjects, careers, fee, true));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public boolean isCourseSaved(long userId, long courseId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_SAVED + " WHERE user_id = ? AND course_id = ?",
                new String[]{String.valueOf(userId), String.valueOf(courseId)});
        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) cursor.close();
        return exists;
    }

    public void toggleSaveCourse(long userId, long courseId, boolean save) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (save) {
            ContentValues cv = new ContentValues();
            cv.put("user_id", userId);
            cv.put("course_id", courseId);
            db.insertWithOnConflict(TABLE_SAVED, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        } else {
            db.delete(TABLE_SAVED, "user_id = ? AND course_id = ?",
                    new String[]{String.valueOf(userId), String.valueOf(courseId)});
        }
    }

    // Eligibility Operations
    public EligibilityRule getEligibilityRuleForCourse(long courseId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT r.*, c.name as course_name FROM " + TABLE_RULES + " r " +
                "INNER JOIN " + TABLE_COURSES + " c ON r.course_id = c.id WHERE r.course_id = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(courseId)});
        EligibilityRule rule = null;
        if (cursor != null && cursor.moveToFirst()) {
            String courseName = cursor.getString(cursor.getColumnIndexOrThrow("course_name"));
            String allowedStreams = cursor.getString(cursor.getColumnIndexOrThrow("allowed_streams"));
            double minPerc = cursor.getDouble(cursor.getColumnIndexOrThrow("min_percentage"));
            String reqSubjects = cursor.getString(cursor.getColumnIndexOrThrow("required_subjects"));
            String entranceDetails = cursor.getString(cursor.getColumnIndexOrThrow("entrance_details"));
            String extraCriteria = cursor.getString(cursor.getColumnIndexOrThrow("additional_criteria"));
            rule = new EligibilityRule(courseId, courseName, allowedStreams, minPerc, reqSubjects, entranceDetails, extraCriteria);
            cursor.close();
        }
        return rule;
    }

    // Admission Guide Operations
    public List<AdmissionStep> getAdmissionSteps() {
        List<AdmissionStep> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_STEPS, null, null, null, null, null, "step_number ASC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int stepNum = cursor.getInt(cursor.getColumnIndexOrThrow("step_number"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String deadline = cursor.getString(cursor.getColumnIndexOrThrow("deadline"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                list.add(new AdmissionStep(stepNum, title, desc, deadline, status));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public List<DocumentItem> getDocuments() {
        List<DocumentItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_DOCUMENTS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                boolean isReq = cursor.getInt(cursor.getColumnIndexOrThrow("is_required")) == 1;
                list.add(new DocumentItem(id, title, category, isReq, false));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    // Multi-Source Smart Chatbot Query Engine
    public String findBestFaqAnswer(String userQuery) {
        if (userQuery == null || userQuery.trim().isEmpty()) {
            return "Please type a question regarding course options, eligibility, fees, or documents.";
        }

        String rawQuery = userQuery.trim();
        String cleaned = rawQuery.toLowerCase()
                .replaceAll("b\\.tech", "btech")
                .replaceAll("b\\.ca", "bca")
                .replaceAll("b\\.ba", "bba")
                .replaceAll("b\\.sc", "bsc")
                .replaceAll("b\\.com", "bcom")
                .replaceAll("b\\.a", "ba")
                .replaceAll("b\\.m\\.s", "bms")
                .replaceAll("b\\.a\\.f", "baf")
                .replaceAll("[^a-z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();

        // --- Intent 1: Commerce Stream Courses Inquiry ---
        if (cleaned.contains("commerce") || cleaned.contains("accounts") || cleaned.contains("business")) {
            if (cleaned.contains("eligib") || cleaned.contains("criteria") || cleaned.contains("mark") || cleaned.contains("percent")) {
                return "Commerce Stream Eligibility:\n• B.Com & B.Com Specializations (BAF/BBI/BFM): Minimum 50-55% in 12th Commerce.\n• BBA & BMS: Open to Commerce/Science/Arts with 50% minimum aggregate.\n• Economics: Requires 12th Commerce or Arts with Economics/Math background.";
            } else if (cleaned.contains("fee") || cleaned.contains("cost") || cleaned.contains("price")) {
                return "Commerce Fee Estimates (Sample):\n• B.Com (Honours): ₹50,000/yr\n• BAF / BBI / BFM: ₹52,000 - ₹55,000/yr\n• BBA: ₹75,000/yr\n• BMS: ₹60,000/yr";
            } else {
                List<Course> commCourses = getCourses("Commerce", "", -1);
                StringBuilder sb = new StringBuilder("Popular programs available after Commerce:\n");
                for (Course c : commCourses) {
                    sb.append("• ").append(c.getName()).append(" (").append(c.getDuration()).append(", Min ").append(c.getMinPercentage()).append("%)\n");
                }
                return sb.toString().trim();
            }
        }

        // --- Intent 2: Arts / Humanities Stream Courses Inquiry ---
        if (cleaned.contains("arts") || cleaned.contains("humanities")) {
            if (cleaned.contains("eligib") || cleaned.contains("criteria") || cleaned.contains("mark") || cleaned.contains("percent")) {
                return "Arts / Humanities Eligibility:\n• B.A. Majors (English, Psychology, History, Political Science, Sociology, Geography, Economics): Minimum 50% in 12th Arts/Humanities.\n• Journalism (BJMC), BSW, BFA: Minimum 50% in 12th in any stream.\n• BCA & BBA are also open to Arts stream students!";
            } else if (cleaned.contains("fee") || cleaned.contains("cost") || cleaned.contains("price")) {
                return "Arts / Humanities Fees (Sample):\n• B.A. Programs: ₹35,000 - ₹40,000/yr\n• BFA (Fine Arts): ₹50,000/yr\n• Journalism (BJMC): ₹60,000/yr\n• BSW: ₹42,000/yr";
            } else {
                List<Course> artsCourses = getCourses("Arts", "", -1);
                StringBuilder sb = new StringBuilder("Popular programs available after Arts / Humanities:\n");
                for (Course c : artsCourses) {
                    sb.append("• ").append(c.getName()).append(" (").append(c.getDuration()).append(", Min ").append(c.getMinPercentage()).append("%)\n");
                }
                sb.append("• BCA & BBA are also open to Arts students!");
                return sb.toString().trim();
            }
        }

        // --- Intent 3: Science Stream Courses Inquiry ---
        if (cleaned.contains("science") || cleaned.contains("engineering") || cleaned.contains("pcm") || cleaned.contains("pcb")) {
            if (cleaned.contains("eligib") || cleaned.contains("criteria") || cleaned.contains("mark") || cleaned.contains("percent")) {
                return "Science Eligibility:\n• B.Tech CSE: 12th Science (PCM) with 60% min & entrance exam.\n• B.Sc Data Science & AI: 12th Science with 55% min (Math required).\n• BCA & BBA are also open to Science graduates.";
            } else {
                List<Course> sciCourses = getCourses("Science", "", -1);
                StringBuilder sb = new StringBuilder("Popular programs available after Science:\n");
                for (Course c : sciCourses) {
                    sb.append("• ").append(c.getName()).append(" (").append(c.getDuration()).append(", Min ").append(c.getMinPercentage()).append("%)\n");
                }
                return sb.toString().trim();
            }
        }

        // --- Intent 4: Specific Course Information Query ---
        List<Course> allCourses = getCourses("All", "", -1);
        for (Course course : allCourses) {
            String courseLower = course.getName().toLowerCase();
            String shortCode = getShortCode(courseLower);

            if ((shortCode != null && cleaned.contains(shortCode)) || courseLower.contains(cleaned) || (cleaned.length() >= 3 && courseLower.contains(cleaned))) {
                EligibilityRule rule = getEligibilityRuleForCourse(course.getId());
                if (cleaned.contains("eligib") || cleaned.contains("criteria") || cleaned.contains("mark") || cleaned.contains("req") || cleaned.contains("percent")) {
                    return course.getName() + " Eligibility:\n• Allowed Stream: " + (rule != null ? rule.getAllowedStreams() : course.getStream()) +
                            "\n• Minimum 12th Score: " + course.getMinPercentage() + "%" +
                            "\n• Prerequisites: " + (rule != null ? rule.getRequiredSubjects() : "English in 12th") +
                            "\n• Entrance: " + (rule != null ? rule.getEntranceExamDetails() : "Merit / Entrance test");
                } else if (cleaned.contains("fee") || cleaned.contains("cost") || cleaned.contains("price") || cleaned.contains("tuition")) {
                    return course.getName() + " Fee Estimate: " + course.getFeeEstimate() + ".";
                } else {
                    return course.getName() + " Details:\n• Stream: " + course.getStream() +
                            "\n• Duration: " + course.getDuration() +
                            "\n• Min Score: " + course.getMinPercentage() + "%" +
                            "\n• Overview: " + course.getDescription() +
                            "\n• Careers: " + course.getCareerOpportunities();
                }
            }
        }

        // --- Intent 5: General Categories (Documents, Deadlines, Fees, All Courses) ---
        if (cleaned.contains("course") || cleaned.contains("program") || cleaned.contains("degree") || cleaned.contains("list") || cleaned.contains("offer")) {
            return "We offer 19 undergraduate degrees across Science, Commerce, and Arts:\n• Commerce: B.Com, BAF, BBI, BFM, BBA, BMS, Economics\n• Arts: B.A. English, Psychology, History, Political Science, Sociology, Geography, Journalism, BSW, BFA\n• Science: B.Tech CSE, B.Sc Data Science\n• Open to All: BCA, BBA, BMS";
        }

        if (cleaned.contains("doc") || cleaned.contains("certificate") || cleaned.contains("marksheet") || cleaned.contains("proof") || cleaned.contains("upload")) {
            return "Required Application Documents:\n• 10th & 12th Marksheets\n• Government ID (Aadhaar / Passport)\n• 4 Passport Photographs\n• Transfer & Migration Certificate\n• Entrance Scorecard (JEE/CUET if applicable)";
        }

        if (cleaned.contains("date") || cleaned.contains("deadline") || cleaned.contains("schedule") || cleaned.contains("when") || cleaned.contains("last date")) {
            return "Admission Schedule:\n• Registration Deadline: June 15, 2026\n• Document Upload: June 25, 2026\n• Entrance / Merit List: July 05, 2026\n• Seat Allotment: July 15, 2026";
        }

        // --- Intent 6: SQLite FAQs Token Matching ---
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FAQS, null, null, null, null, null, null);

        String bestAnswer = null;
        int maxScore = 0;

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndexOrThrow("question")).toLowerCase();
                String keywords = cursor.getString(cursor.getColumnIndexOrThrow("keywords")).toLowerCase();
                String answer = cursor.getString(cursor.getColumnIndexOrThrow("answer"));

                int score = 0;
                String[] words = cleaned.split("\\s+");
                for (String word : words) {
                    if (word.length() >= 2) {
                        if (question.contains(word)) score += 3;
                        if (keywords.contains(word)) score += 2;
                    }
                }

                if (score > maxScore) {
                    maxScore = score;
                    bestAnswer = answer;
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        if (bestAnswer != null && maxScore >= 1) {
            return bestAnswer;
        }

        return "I am your College Admission Assistant. Ask me about:\n• Courses after Commerce, Arts, or Science\n• Eligibility for BCA, B.Com, BBA, or B.Tech\n• Required application documents & deadlines\n• Fee structures";
    }

    private String getShortCode(String courseLower) {
        if (courseLower.contains("computer applications") || courseLower.contains("bca")) return "bca";
        if (courseLower.contains("b.tech") || courseLower.contains("btech")) return "btech";
        if (courseLower.contains("bba") || courseLower.contains("business administration")) return "bba";
        if (courseLower.contains("bms") || courseLower.contains("management studies")) return "bms";
        if (courseLower.contains("baf") || courseLower.contains("accounting & finance")) return "baf";
        if (courseLower.contains("bbi") || courseLower.contains("banking & insurance")) return "bbi";
        if (courseLower.contains("bfm") || courseLower.contains("financial markets")) return "bfm";
        if (courseLower.contains("english")) return "english";
        if (courseLower.contains("psychology")) return "psychology";
        if (courseLower.contains("history")) return "history";
        if (courseLower.contains("political science")) return "political science";
        if (courseLower.contains("sociology")) return "sociology";
        if (courseLower.contains("geography")) return "geography";
        if (courseLower.contains("journalism")) return "journalism";
        if (courseLower.contains("fine arts") || courseLower.contains("bfa")) return "bfa";
        if (courseLower.contains("social work") || courseLower.contains("bsw")) return "bsw";
        if (courseLower.contains("b.com") || courseLower.contains("bcom") || courseLower.contains("commerce")) return "bcom";
        return null;
    }
}
