package com.mit.admissionassistant.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public class PreferenceManager {
    private static final String PREF_NAME = "AdmissionAssistantPrefs";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_STREAM = "user_stream";
    private static final String KEY_USER_PERCENTAGE = "user_percentage";
    private static final String KEY_CHECKED_DOCS = "checked_documents";
    private static final String KEY_DOC_FILE_PREFIX = "doc_file_";

    private final SharedPreferences prefs;

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveUserSession(long id, String name, String email, String stream, double percentage) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putLong(KEY_USER_ID, id);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_STREAM, stream);
        editor.putFloat(KEY_USER_PERCENTAGE, (float) percentage);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public long getUserId() {
        return prefs.getLong(KEY_USER_ID, -1);
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "Student");
    }

    public String getUserEmail() {
        return prefs.getString(KEY_USER_EMAIL, "student@example.com");
    }

    public String getUserStream() {
        return prefs.getString(KEY_USER_STREAM, "Science");
    }

    public double getUserPercentage() {
        return prefs.getFloat(KEY_USER_PERCENTAGE, 75.0f);
    }

    public Set<String> getCheckedDocuments() {
        return prefs.getStringSet(KEY_CHECKED_DOCS, new HashSet<>());
    }

    public void setDocumentChecked(String docId, boolean isChecked) {
        Set<String> currentDocs = new HashSet<>(getCheckedDocuments());
        if (isChecked) {
            currentDocs.add(docId);
        } else {
            currentDocs.remove(docId);
        }
        prefs.edit().putStringSet(KEY_CHECKED_DOCS, currentDocs).apply();
    }

    public void saveUploadedDocument(String docId, String fileName) {
        prefs.edit().putString(KEY_DOC_FILE_PREFIX + docId, fileName).apply();
        setDocumentChecked(docId, true); // Auto-check when uploaded
    }

    public String getUploadedDocument(String docId) {
        return prefs.getString(KEY_DOC_FILE_PREFIX + docId, null);
    }

    public void clearSession() {
        prefs.edit().clear().apply();
    }
}
