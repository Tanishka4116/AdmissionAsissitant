$headers = @{
    "Authorization" = "Bearer xai-clMbW68zGWHHuTf3ZqRZz97CnbbUA30K79rWPAkFy8VZjyVKHAk2kGSU3bJyp3T0Xx5YVfDxIcLKzxuz"
    "Content-Type" = "application/json"
}

$bodyObj = @{
    model = "grok-4.7"
    messages = @(
        @{ role = "system"; content = "You are a helpful assistant." },
        @{ role = "user"; content = "Hello, are you working?" }
    )
    stream = $false
}

$jsonBody = $bodyObj | ConvertTo-Json -Depth 5

try {
    $res = Invoke-RestMethod -Uri "https://api.x.ai/v1/chat/completions" -Method Post -Headers $headers -Body $jsonBody
    Write-Host "SUCCESS:"
    $res.choices[0].message.content
} catch {
    Write-Host "ERROR:"
    $_.Exception.Message
    if ($_.Exception.Response) {
        $stream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        Write-Host "RESPONSE BODY:"
        $reader.ReadToEnd()
    }
}
