$apiKey = "AQ.Ab8RN6LvTe-G7f6UbKO41ymaifLtIGEp05AJozmLbqV1v-ZYPg"
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"

$headers = @{
    "x-goog-api-key" = $apiKey
    "Content-Type" = "application/json"
}

$bodyObj = @{
    contents = @(
        @{
            parts = @(
                @{ text = "Hello, are you working?" }
            )
        }
    )
}

$jsonBody = $bodyObj | ConvertTo-Json -Depth 5

try {
    $res = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $jsonBody
    Write-Host "SUCCESS:"
    $res.candidates[0].content.parts[0].text
} catch {
    Write-Host "ERROR:"
    $_.Exception.Message
    if ($_.Exception.Response) {
        $stream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        Write-Host "RESPONSE BODY:"
        $reader.ReadToEnd()
    }
}
