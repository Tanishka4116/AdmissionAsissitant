# College Admission Assistant — Native Android Application

A comprehensive native Android application developed in Java as a Mobile Application Development (MAD) project. The application assists prospective students in exploring undergraduate programs across Science, Commerce, and Arts streams, evaluating detailed rule-based eligibility, managing required admission document checklists, querying an offline AI/FAQ Chatbot, and saving course bookmarks.

---

## 🌟 Key Features & Implemented Modules

### 1. 🎓 Course Directory Module (19 Programs Across Science, Commerce & Arts)
- **Science Programs**: `B.Tech CSE`, `B.Sc. Data Science & AI`.
- **Commerce Programs**: `B.Com (Honours)`, `B.Com Accounting & Finance (BAF)`, `B.Com Banking & Insurance (BBI)`, `B.Com Financial Markets (BFM)`, `BBA`, `BMS (Management Studies)`, `Economics`.
- **Arts & Humanities Programs**: `B.A. English`, `B.A. Psychology`, `B.A. History`, `B.A. Political Science`, `B.A. Sociology`, `B.A. Geography`, `Journalism and Mass Communication`, `BSW (Social Work)`, `BFA (Fine Arts)`.
- **Open / Multi-Stream Programs**: `BCA`, `BBA`, `BMS`.
- **Interactive Search & Filter**: Real-time keyword search and stream filter (`All`, `Science`, `Commerce`, `Arts`).

### 2. ⚡ Rule-Based Eligibility Checker Module
- **Multi-Factor Rules**: Evaluates student stream, 12th percentage, and optional entrance scores (e.g., JEE / CUET).
- **Dynamic Result Engine**: Calculates eligibility status (`ELIGIBLE` vs. `INELIGIBLE`) with a detailed comparison breakdown.

### 3. 📋 Admission Guide & Persistent Document Checklist
- **Step-by-Step Guidance**: View active and upcoming admission stages with deadlines.
- **Interactive Document Upload & Checklist**: Check off requirements (10th/12th marksheets, ID proof, photos, transfer certificate).
- **Document Upload System**: Tap "Upload" on any requirement to select PDF/Image files from device storage with persistent state saving.

### 4. 🤖 Multi-Source Smart Chatbot
- **Interactive Manual Input & Keyboard Actions**: Fully supports manual text input and soft keyboard `Send` action.
- **Dynamic Stream & Course Search**:
  - Asks "courses after Commerce" -> Lists B.Com, BAF, BBI, BFM, BBA, BMS, Economics.
  - Asks "courses after Arts" -> Lists B.A. English, Psychology, History, Political Science, Sociology, Journalism, BSW, BFA.
  - Asks "eligibility for BCA" -> Retrieves exact BCA criteria from database.
- **Fallback Answer**: Friendly guidance when queries are unrecognized.

### 5. 👤 Student Profile & Saved Courses
- **User Dashboard**: Displays student academic profile details (Name, Email, Stream, 12th Score).
- **Saved Courses**: View and manage bookmarked programs.
- **Session Management**: One-click Sign Out functionality.

### 6. 🔐 Authentication & Database Migration
- **Secure Storage**: SHA-256 password hashing stored in SQLite database.
- **Safe Database Migration (v2)**: Idempotent seeding preserving user accounts and saved bookmarks across updates.
- **One-Click Demo Student Login**: Instant login option (`demo@college.edu`) for quick project review.

---

## 📁 Project Code Map & File Mapping

### 1. Java Source Code (`app/src/main/java/com/mit/admissionassistant/`)

#### 🏢 Activities
| Class Name | Description |
| :--- | :--- |
| `SplashActivity.java` | Screen 1 launcher showing the official logo and navigating based on session state |
| `LoginActivity.java` | Sign in screen with SHA-256 password validation & One-Click Demo Student Login |
| `RegisterActivity.java` | Signup screen collecting candidate details, academic stream, and 12th score |
| `MainActivity.java` | Main host activity managing `BottomNavigationView` tabs and top bar session header |
| `CourseDetailActivity.java` | Full program information, career prospects, estimated fees, and bookmark toggle |

#### 🧩 Fragments (Main Tab Destinations)
| Fragment Name | Description |
| :--- | :--- |
| `HomeFragment.java` | Dashboard with welcome card, search bar, quick action shortcuts, and featured courses |
| `CoursesFragment.java` | Full course directory with stream spinner filter (`All`, `Science`, `Commerce`, `Arts`) and real-time text search |
| `EligibilityFragment.java` | Input form evaluating student scores against course-specific eligibility rules |
| `AdmissionFragment.java` | Step-by-step application workflow & persistent document checklist with upload option |
| `ChatbotFragment.java` | Offline chatbot interface handling manual text queries and suggestion chips |
| `ProfileFragment.java` | Student profile info, bookmarked courses list, and logout button |

#### 🔀 Adapters (`com.mit.admissionassistant.adapters`)
| Adapter Class | Associated XML Layout | Description |
| :--- | :--- | :--- |
| `CourseAdapter.java` | `item_course.xml` | RecyclerView adapter for course cards with bookmark button |
| `AdmissionStepAdapter.java` | `item_admission_step.xml` | RecyclerView adapter for admission workflow stages |
| `DocumentAdapter.java` | `item_document.xml` | RecyclerView adapter for document checklist with file upload button |
| `ChatAdapter.java` | `item_chat_user.xml`, `item_chat_bot.xml` | Chat bubble adapter displaying user queries and bot responses |

#### 💾 Database & Utilities (`com.mit.admissionassistant.db` / `utils`)
| Class Name | Description |
| :--- | :--- |
| `DatabaseHelper.java` | SQLite OpenHelper (v2) managing safe migration and tables (`users`, `courses`, `eligibility_rules`, `admission_steps`, `documents`, `saved_courses`, `faqs`) |
| `PreferenceManager.java` | Manages `SharedPreferences` session, student profile, and persistent document checklist state |
| `SecurityUtils.java` | SHA-256 password hashing helper |

---

## ⚙️ Building & Running the Application

### Prerequisites
- **Android Studio**: Android Studio Jellyfish / Ladybug or newer
- **JDK**: Java Development Kit 11+
- **Compile SDK**: 37 (Min SDK 26)

### Steps
1. Open the project folder in Android Studio.
2. Build the project using Gradle:
   ```bash
   ./gradlew app:assembleDebug
   ```
3. Run the application on an Android Emulator or connected device.

---

## ✅ Verification & Test Summary
- **Build Status**: Successful (`./gradlew app:assembleDebug`).
- **Unit Tests**: Passed (`1 passed, 0 skipped, 0 failed`).
